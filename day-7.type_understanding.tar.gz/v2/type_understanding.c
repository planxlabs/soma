#include "common.h"
#include "bin.h"

int main() 
{
    char char_data;
    float float_data;    
    char bin[64];
    char data[64];

    do {
        scanf("%s",data);

        char *ret = strstr(data, ".");
        if (ret != NULL) {
            if (strstr(ret+1, ".") != NULL) break;
            float_data = (float)atof(data);
            data2bin(&float_data, bin, TYPE_FLOAT);
        }
        else {
            char_data = (char)atoi(data);
            data2bin(&char_data, bin, TYPE_CHAR);
        }
        printf("%s\n", bin);
    }while(true);

    return 0;
}