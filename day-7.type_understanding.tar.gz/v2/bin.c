#include "common.h"
#include "bin.h"

int data2bin(void *data, char *ret, type_t type)
{
    bin_t *p = (bin_t *)data;

    if (type == TYPE_CHAR) {
        sprintf(ret, "%d%d%d%d-%d%d%d%d",p->d7, p->d6, p->d5, p->d4, p->d3, p->d2, p->d1, p->d0);    
    }
    else if (type == TYPE_FLOAT) {
        float_t *extra = (float_t *)data;
        sprintf(ret, "%d:%d%d%d%d-%d%d%d%d:%d%d%d-%d%d%d%d-%d%d%d%d-%d%d%d%d-%d%d%d%d-%d%d%d%d (%d:%d)",
                        p->d31, 
                        p->d30, p->d29, p->d28, p->d27, p->d26, p->d25, p->d24, p->d23,
                        p->d22, p->d21, p->d20, p->d19, p->d18, p->d17, p->d16, p->d15,
                        p->d14, p->d13, p->d12, p->d11, p->d10, p->d9, p->d8, p->d7,
                        p->d6, p->d5, p->d4, p->d3, p->d2, p->d1, p->d0,
                        extra->e, extra->m);    
    }
    else {
        return -1;
    }

    return 0;
}
