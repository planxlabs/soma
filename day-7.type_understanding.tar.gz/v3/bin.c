#include "common.h"
#include "bin.h"

typedef struct {
    unsigned int m:23, e:8, s:1;
} float_t;

int data2bin(void *data, char *ret, type_t type)
{
    char buf[32+1] = {0,};

    uint32_t *p = (uint32_t *)data;
    int i;

    if (type == TYPE_CHAR) {
        for (i = 0; i < 8; i++) {
            buf[7-i] = '0' + ((*p >> i) & 0x01);
        }
        sprintf(ret, "%s", buf);
    }
    else if (type == TYPE_FLOAT) {
        float_t *extra = (float_t *)data;
        for (i = 0; i < 32; i++) {
            buf[31-i] = '0' + ((*p >> i) & 0x01);
        }
        sprintf(ret, "%s(%d:%d)", buf, extra->e, extra->m);
    }
    else {
        return -1;
    }
    
    return 0;
}
