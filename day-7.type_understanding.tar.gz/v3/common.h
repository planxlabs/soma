#ifndef _COMMON_H_

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#include <stdio.h>

#endif