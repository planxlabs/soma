#ifndef _BIN_H_

typedef enum {TYPE_CHAR, TYPE_FLOAT} type_t;

extern int data2bin(void *data, char *ret, type_t type);
#endif