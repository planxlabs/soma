#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>

typedef struct {
    unsigned int 
        d0:1, d1:1, d2:1, d3:1, d4:1, d5:1, d6:1, d7:1,
        d8:1, d9:1, d10:1, d11:1, d12:1, d13:1, d14:1, d15:1,
        d16:1, d17:1, d18:1, d19:1, d20:1, d21:1, d22:1, d23:1,
        d24:1, d25:1, d26:1, d27:1, d28:1, d29:1, d30:1, d31:1;
} bin_t;

typedef struct {
    unsigned int m:23, e:8, s:1;
} float_t;

typedef enum {TYPE_CHAR, TYPE_FLOAT} type_t;

int data2bin(void *data, char *ret, type_t type)
{
    bin_t *p = (bin_t *)data;

    if (type == TYPE_CHAR) {
        sprintf(ret, "%d%d%d%d-%d%d%d%d",p->d7, p->d6, p->d5, p->d4, p->d3, p->d2, p->d1, p->d0);    
    }
    else if (type == TYPE_FLOAT) {
        float_t *extra = (float_t *)data;
        sprintf(ret, "%d:%d%d%d%d-%d%d%d%d:%d%d%d-%d%d%d%d-%d%d%d%d-%d%d%d%d-%d%d%d%d-%d%d%d%d (%d:%d)",
                        p->d31, 
                        p->d30, p->d29, p->d28, p->d27, p->d26, p->d25, p->d24, p->d23,
                        p->d22, p->d21, p->d20, p->d19, p->d18, p->d17, p->d16, p->d15,
                        p->d14, p->d13, p->d12, p->d11, p->d10, p->d9, p->d8, p->d7,
                        p->d6, p->d5, p->d4, p->d3, p->d2, p->d1, p->d0,
                        extra->e, extra->m);    
    }
    else {
        return -1;
    }

    return 0;
}

int main() 
{
    char char_data;
    float float_data;    
    char bin[64];
    char data[64];

    do {
        scanf("%s",data);
        
        char *ret = strstr(data, ".");
        if (ret != NULL) {
            if (strstr(ret+1, ".") != NULL) break;
            float_data = (float)atof(data);
            data2bin(&float_data, bin, TYPE_FLOAT);
        }
        else {
            char_data = (char)atoi(data);
            data2bin(&char_data, bin, TYPE_CHAR);
        }
        printf("%s\n", bin);
    }while(true);

    return 0;
}